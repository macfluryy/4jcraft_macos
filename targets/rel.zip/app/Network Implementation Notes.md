# Network Code Implementation Notes

## Overview

The networking classes are organized as follows:

```
									Game														\
									  ^															|
									  |															|
		+-----------------------------+-----------------------------+							|
		|															|							|
		v															v							|
Game Network Manager <--------------------------------> Network Player Interface				|-		platform independent layers
		^															^							|
		|															|							|						
		v															|							|
Platform Network Manager Interface									|							|
		^															|							/
		|															|							
		v															v							\
Platform Network Manager Implementation(1) <------> Network Player Implementation (3)			|
		^															^							|_		platform specific layers
		|															|							|
		v															v							|
Platform specific network code(2)				   Platform specific player code (4)			/
```

### Notes

- In general the game should **only communicate with the `GameNetworkManager` and `NetworkPlayerInterface` APIs**, which provide a platform independent interface for networking functionality. The `GameNetworkManager` may in general have code which is aware of the game itself, but it *shouldn't have any platform-specific networking code*. It communicates with a platform specific implementation of a `PlatformNetworkManagerInterface` to achieve this.

- The platform specific layers shouldn't contain any general game code, as this is much better placed in the platform independent layers to avoid duplicating effort.

- Platform specific files for each platform for the numbered classes in the previous diagram are currently:


## Platform-Specific Files

The platform-specific implementations for each numbered class in the diagram:

| Class | Xbox 360                        | Sony                        | Other                  |
|-------|---------------------------------|----------------------------|-----------------------|
| (1)   | PlatformNetworkManagerXbox     | PlatformNetworkManagerSony | PlatformNetworkManagerStub |
| (2)   | Provided by QNET                 | SQRNetworkManager        | Qnet stub*            |
| (3)   | NetworkPlayerXbox              | NetworkPlayerSony        | NetworkPlayerXbox   |
| (4)   | Provided by QNET                 | SQRNetworkPlayer         | Qnet stub*            |
\*Temporarily provided by `extra64.h`
