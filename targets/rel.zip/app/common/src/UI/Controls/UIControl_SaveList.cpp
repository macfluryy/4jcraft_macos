#include "UIControl_SaveList.h"

#include "app/common/src/UI/Controls/UIControl.h"
#include "app/common/src/UI/Controls/UIControl_ButtonList.h"
#include "app/common/src/UI/UIScene.h"
#include "app/mac/Iggy/include/iggy.h"
#ifndef _ENABLEIGGY
#include "app/mac/Stubs/iggy_stubs.h"
#endif
#include "app/mac/Iggy/include/rrCore.h"
#include "util/StringHelpers.h"

bool UIControl_SaveList::setupControl(UIScene* scene, IggyValuePath* parent,
                                      const std::string& controlName) {
    UIControl::setControlType(UIControl::eSaveList);
    bool success =
        UIControl_ButtonList::setupControl(scene, parent, controlName);

    // SlotList specific initialisers
    m_funcSetTextureName = registerFastName(L"SetTextureName");

    return success;
}

void UIControl_SaveList::addItem(const std::wstring& label) {
    addItem(label, L"");
}

void UIControl_SaveList::addItem(const std::string& label) {
    addItem(label, L"");
}

void UIControl_SaveList::addItem(const std::wstring& label, int data) {
    addItem(label, L"", data);
}

void UIControl_SaveList::addItem(const std::string& label, int data) {
    addItem(label, L"", data);
}

void UIControl_SaveList::addItem(const std::string& label,
                                 const std::wstring& iconName) {
    addItem(label, iconName, m_itemCount);
    ++m_itemCount;
}

void UIControl_SaveList::addItem(const std::wstring& label,
                                 const std::wstring& iconName) {
    addItem(label, iconName, m_itemCount);
    ++m_itemCount;
}

void UIControl_SaveList::addItem(const std::string& label,
                                 const std::wstring& iconName, int data) {
    IggyDataValue result;
    IggyDataValue value[3];

    IggyStringUTF8 stringVal;
    stringVal.string = (char*)label.c_str();
    stringVal.length = (S32)label.length();
    value[0].type = IGGY_DATATYPE_string_UTF8;
    value[0].string8 = stringVal;

    value[1].type = IGGY_DATATYPE_number;
    value[1].number = m_itemCount;

    const std::u16string convName = wstring_to_u16string(iconName);

    IggyStringUTF16 stringVal2;
    stringVal2.string = convName.c_str();
    stringVal2.length = convName.length();
    value[2].type = IGGY_DATATYPE_string_UTF16;
    value[2].string16 = stringVal2;
    IggyResult out =
        IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                               getIggyValuePath(), m_addNewItemFunc, 3, value);
}

void UIControl_SaveList::addItem(const std::wstring& label,
                                 const std::wstring& iconName, int data) {
    IggyDataValue result;
    IggyDataValue value[3];

    const std::u16string convLabel = wstring_to_u16string(label);

    IggyStringUTF16 stringVal;
    stringVal.string = convLabel.c_str();
    stringVal.length = (S32)convLabel.length();
    value[0].type = IGGY_DATATYPE_string_UTF16;
    value[0].string16 = stringVal;

    value[1].type = IGGY_DATATYPE_number;
    value[1].number = m_itemCount;

    const std::u16string convName = wstring_to_u16string(iconName);

    IggyStringUTF16 stringVal2;
    stringVal2.string = convName.c_str();
    stringVal2.length = convName.length();
    value[2].type = IGGY_DATATYPE_string_UTF16;
    value[2].string16 = stringVal2;
    IggyResult out =
        IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                               getIggyValuePath(), m_addNewItemFunc, 3, value);
}

void UIControl_SaveList::setTextureName(int iId, const std::wstring& iconName) {
    IggyDataValue result;
    IggyDataValue value[2];

    value[0].type = IGGY_DATATYPE_number;
    value[0].number = iId;

    const std::u16string convName = wstring_to_u16string(iconName);

    IggyStringUTF16 stringVal;
    stringVal.string = convName.c_str();
    stringVal.length = convName.length();
    value[1].type = IGGY_DATATYPE_string_UTF16;
    value[1].string16 = stringVal;
    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_funcSetTextureName, 2, value);
}
