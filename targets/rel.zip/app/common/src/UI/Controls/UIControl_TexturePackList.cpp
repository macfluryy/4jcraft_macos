#include "UIControl_TexturePackList.h"

#include "app/common/src/UI/Controls/UIControl.h"
#include "app/common/src/UI/Controls/UIControl_Base.h"
#include "app/common/src/UI/UIScene.h"
#include "app/common/src/UI/UIString.h"
#include "app/mac/Iggy/include/iggy.h"
#ifndef _ENABLEIGGY
#include "app/mac/Stubs/iggy_stubs.h"
#endif
#include "app/mac/Iggy/include/rrCore.h"
#include "util/StringHelpers.h"

UIControl_TexturePackList::UIControl_TexturePackList() {}

bool UIControl_TexturePackList::setupControl(UIScene* scene,
                                             IggyValuePath* parent,
                                             const std::string& controlName) {
    UIControl::setControlType(UIControl::eTexturePackList);
    bool success = UIControl_Base::setupControl(scene, parent, controlName);

    // SlotList specific initialisers
    m_addPackFunc = registerFastName(L"addPack");
    m_clearSlotsFunc = registerFastName(L"removeAllItems");
    m_funcSelectSlot = registerFastName(L"SelectSlot");
    m_funcEnableSelector = registerFastName(L"EnableSelector");
    m_funcSetTouchFocus = registerFastName(L"SetTouchFocus");
    m_funcCanTouchTrigger = registerFastName(L"CanTouchTrigger");
    m_funcGetRealHeight = registerFastName(L"GetRealHeight");

    return success;
}

void UIControl_TexturePackList::init(const std::wstring& label, int id) {
    m_label = label;
    m_id = id;

    const std::u16string convLabel = wstring_to_u16string(label);

    IggyDataValue result;
    IggyDataValue value[2];
    value[0].type = IGGY_DATATYPE_string_UTF16;
    IggyStringUTF16 stringVal;

    stringVal.string = convLabel.c_str();
    stringVal.length = convLabel.length();
    value[0].string16 = stringVal;

    value[1].type = IGGY_DATATYPE_number;
    value[1].number = id;
    IggyResult out =
        IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                               getIggyValuePath(), m_initFunc, 2, value);
}

void UIControl_TexturePackList::addPack(int id,
                                        const std::wstring& textureName) {
    const std::u16string convName = wstring_to_u16string(textureName);

    IggyDataValue result;
    IggyDataValue value[2];
    value[0].type = IGGY_DATATYPE_number;
    value[0].number = id;

    value[1].type = IGGY_DATATYPE_string_UTF16;
    IggyStringUTF16 stringVal;

    stringVal.string = convName.c_str();
    stringVal.length = convName.length();
    value[1].string16 = stringVal;
    IggyResult out =
        IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                               getIggyValuePath(), m_addPackFunc, 2, value);
}

void UIControl_TexturePackList::selectSlot(int id) {
    IggyDataValue result;
    IggyDataValue value[1];
    value[0].type = IGGY_DATATYPE_number;
    value[0].number = id;
    IggyResult out =
        IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                               getIggyValuePath(), m_funcSelectSlot, 1, value);
}

void UIControl_TexturePackList::clearSlots() {
    IggyDataValue result;
    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_clearSlotsFunc, 0, nullptr);
}

void UIControl_TexturePackList::setEnabled(bool enable) {
    IggyDataValue result;
    IggyDataValue value[1];
    value[0].type = IGGY_DATATYPE_boolean;
    value[0].number = enable;
    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_funcEnableSelector, 1, value);
}

void UIControl_TexturePackList::SetTouchFocus(S32 iX, S32 iY, bool bRepeat) {
    IggyDataValue result;
    IggyDataValue value[3];

    value[0].type = IGGY_DATATYPE_number;
    value[0].number = iX;
    value[1].type = IGGY_DATATYPE_number;
    value[1].number = iY;
    value[2].type = IGGY_DATATYPE_boolean;
    value[2].boolval = bRepeat;

    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_funcSetTouchFocus, 3, value);
}

bool UIControl_TexturePackList::CanTouchTrigger(S32 iX, S32 iY) {
    IggyDataValue result;
    IggyDataValue value[2];

    value[0].type = IGGY_DATATYPE_number;
    value[0].number = iX;
    value[1].type = IGGY_DATATYPE_number;
    value[1].number = iY;

    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_funcCanTouchTrigger, 2, value);

    S32 bCanTouchTrigger = false;
    if (result.type == IGGY_DATATYPE_boolean) {
        bCanTouchTrigger = (bool)result.boolval;
    }
    return bCanTouchTrigger;
}

S32 UIControl_TexturePackList::GetRealHeight() {
    IggyDataValue result;
    IggyResult out = IggyPlayerCallMethodRS(m_parentScene->getMovie(), &result,
                                            getIggyValuePath(),
                                            m_funcGetRealHeight, 0, nullptr);

    S32 iRealHeight = m_height;
    if (result.type == IGGY_DATATYPE_number) {
        iRealHeight = (S32)result.number;
    }
    return iRealHeight;
}
