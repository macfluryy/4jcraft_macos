#include "IUIScene_AnvilMenu.h"

#include <assert.h>
#include <wchar.h>

#include "app/common/src/UI/All Platforms/IUIScene_AbstractContainerMenu.h"
#include "app/mac/MacGame.h"
#include "java/InputOutputStream/ByteArrayOutputStream.h"
#include "java/InputOutputStream/DataOutputStream.h"
#include "minecraft/client/Minecraft.h"
#include "minecraft/client/multiplayer/ClientConnection.h"
#include "minecraft/client/multiplayer/MultiPlayerLocalPlayer.h"
#include "minecraft/network/packet/CustomPayloadPacket.h"
#include "minecraft/world/entity/player/Abilities.h"
#include "minecraft/world/entity/player/Inventory.h"
#include "minecraft/world/entity/player/Player.h"
#include "minecraft/world/inventory/AbstractContainerMenu.h"
#include "minecraft/world/inventory/AnvilMenu.h"
#include "minecraft/world/inventory/MerchantMenu.h"
#include "minecraft/world/inventory/Slot.h"
#include "minecraft/world/item/ItemInstance.h"
#include "strings.h"

IUIScene_AnvilMenu::IUIScene_AnvilMenu() {
    m_inventory = nullptr;
    m_repairMenu = nullptr;
    m_itemName = L"";
}

IUIScene_AbstractContainerMenu::ESceneSection
IUIScene_AnvilMenu::GetSectionAndSlotInDirection(ESceneSection eSection,
                                                 ETapState eTapDirection,
                                                 int* piTargetX,
                                                 int* piTargetY) {
    ESceneSection newSection = eSection;
    int xOffset = 0;

    // Find the new section if there is one
    switch (eSection) {
        case eSectionAnvilItem1:
            if (eTapDirection == eTapStateUp) {
                newSection = eSectionAnvilName;
            } else if (eTapDirection == eTapStateDown) {
                newSection = eSectionAnvilInventory;
                xOffset = ANVIL_SCENE_ITEM1_SLOT_DOWN_OFFSET;
            } else if (eTapDirection == eTapStateLeft) {
                newSection = eSectionAnvilResult;
            } else if (eTapDirection == eTapStateRight) {
                newSection = eSectionAnvilItem2;
            }
            break;
        case eSectionAnvilItem2:
            if (eTapDirection == eTapStateUp) {
                newSection = eSectionAnvilName;
            } else if (eTapDirection == eTapStateDown) {
                newSection = eSectionAnvilInventory;
                xOffset = ANVIL_SCENE_ITEM2_SLOT_DOWN_OFFSET;
            } else if (eTapDirection == eTapStateLeft) {
                newSection = eSectionAnvilItem1;
            } else if (eTapDirection == eTapStateRight) {
                newSection = eSectionAnvilResult;
            }
            break;
        case eSectionAnvilResult:
            if (eTapDirection == eTapStateUp) {
                newSection = eSectionAnvilName;
            } else if (eTapDirection == eTapStateDown) {
                newSection = eSectionAnvilInventory;
                xOffset = ANVIL_SCENE_RESULT_SLOT_DOWN_OFFSET;
            } else if (eTapDirection == eTapStateLeft) {
                newSection = eSectionAnvilItem2;
            } else if (eTapDirection == eTapStateRight) {
                newSection = eSectionAnvilItem1;
            }
            break;
        case eSectionAnvilName:
            if (eTapDirection == eTapStateUp) {
                newSection = eSectionAnvilUsing;
                xOffset = ANVIL_SCENE_ITEM2_SLOT_UP_OFFSET;
            } else if (eTapDirection == eTapStateDown) {
                newSection = eSectionAnvilItem2;
            }
            break;
        case eSectionAnvilInventory:
            if (eTapDirection == eTapStateDown) {
                newSection = eSectionAnvilUsing;
            } else if (eTapDirection == eTapStateUp) {
                if (*piTargetX <= ANVIL_SCENE_ITEM1_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilItem1;
                } else if (*piTargetX <= ANVIL_SCENE_ITEM2_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilItem2;
                } else if (*piTargetX >= ANVIL_SCENE_RESULT_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilResult;
                }
            }
            break;
        case eSectionAnvilUsing:
            if (eTapDirection == eTapStateUp) {
                newSection = eSectionAnvilInventory;
            } else if (eTapDirection == eTapStateDown) {
                if (*piTargetX <= ANVIL_SCENE_ITEM1_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilItem1;
                } else if (*piTargetX <= ANVIL_SCENE_ITEM2_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilName;
                } else if (*piTargetX >= ANVIL_SCENE_RESULT_SLOT_UP_OFFSET) {
                    newSection = eSectionAnvilName;
                }
            }
            break;
        default:
            assert(false);
            break;
    }

    updateSlotPosition(eSection, newSection, eTapDirection, piTargetX,
                       piTargetY, xOffset);

    return newSection;
}

int IUIScene_AnvilMenu::getSectionStartOffset(ESceneSection eSection) {
    int offset = 0;
    switch (eSection) {
        case eSectionAnvilItem1:
            offset = MerchantMenu::PAYMENT1_SLOT;
            break;
        case eSectionAnvilItem2:
            offset = MerchantMenu::PAYMENT2_SLOT;
            break;
        case eSectionAnvilResult:
            offset = MerchantMenu::RESULT_SLOT;
            break;
        case eSectionAnvilInventory:
            offset = MerchantMenu::INV_SLOT_START;
            break;
        case eSectionAnvilUsing:
            offset = MerchantMenu::USE_ROW_SLOT_START;
            break;
        default:
            assert(false);
            break;
    }
    return offset;
}

void IUIScene_AnvilMenu::handleOtherClicked(int iPad, ESceneSection eSection,
                                            int buttonNum, bool quickKey) {
    switch (eSection) {
        case eSectionAnvilName:
            handleEditNamePressed();
            break;
        default:
            break;
    };
}

bool IUIScene_AnvilMenu::IsSectionSlotList(ESceneSection eSection) {
    switch (eSection) {
        case eSectionAnvilUsing:
        case eSectionAnvilInventory:
        case eSectionAnvilItem1:
        case eSectionAnvilItem2:
        case eSectionAnvilResult:
            return true;
        default:
            break;
    }
    return false;
}

void IUIScene_AnvilMenu::handleTick() {
    Minecraft* pMinecraft = Minecraft::GetInstance();
    bool canAfford = true;
    std::wstring m_costString = L"";

    if (m_repairMenu->cost > 0) {
        if (m_repairMenu->cost >= 40 &&
            !pMinecraft->localplayers[getPad()]->abilities.instabuild) {
            m_costString = app.GetString(IDS_REPAIR_EXPENSIVE);
            canAfford = false;
        } else if (!m_repairMenu->getSlot(AnvilMenu::RESULT_SLOT)->hasItem()) {
            // Do nothing
        } else {
            const wchar_t* costString = app.GetString(IDS_REPAIR_COST);
            wchar_t temp[256];
            swprintf(temp, 256, costString, m_repairMenu->cost);
            m_costString = temp;
            if (!m_repairMenu->getSlot(AnvilMenu::RESULT_SLOT)
                     ->mayPickup(std::dynamic_pointer_cast<Player>(
                         m_inventory->player->shared_from_this()))) {
                canAfford = false;
            }
        }
    }
    setCostLabel(m_costString, canAfford);

    bool crossVisible =
        (m_repairMenu->getSlot(AnvilMenu::INPUT_SLOT)->hasItem() ||
         m_repairMenu->getSlot(AnvilMenu::ADDITIONAL_SLOT)->hasItem()) &&
        !m_repairMenu->getSlot(AnvilMenu::RESULT_SLOT)->hasItem();
    showCross(crossVisible);
}

void IUIScene_AnvilMenu::updateItemName() {
    Slot* slot = m_repairMenu->getSlot(AnvilMenu::INPUT_SLOT);
    if (slot != nullptr && slot->hasItem()) {
        if (!slot->getItem()->hasCustomHoverName() &&
            m_itemName.compare(slot->getItem()->getHoverName()) == 0) {
            m_itemName = L"";
        }
    }

    m_repairMenu->setItemName(m_itemName);

    // Convert to std::vector<uint8_t>
    ByteArrayOutputStream baos;
    DataOutputStream dos(&baos);
    dos.writeUTF(m_itemName);
    Minecraft::GetInstance()->localplayers[getPad()]->connection->send(
        std::shared_ptr<CustomPayloadPacket>(new CustomPayloadPacket(
            CustomPayloadPacket::SET_ITEM_NAME_PACKET, baos.toByteArray())));
}

void IUIScene_AnvilMenu::refreshContainer(
    AbstractContainerMenu* container,
    std::vector<std::shared_ptr<ItemInstance> >* items) {
    slotChanged(container, AnvilMenu::INPUT_SLOT,
                container->getSlot(0)->getItem());
}

void IUIScene_AnvilMenu::slotChanged(AbstractContainerMenu* container,
                                     int slotIndex,
                                     std::shared_ptr<ItemInstance> item) {
    if (slotIndex == AnvilMenu::INPUT_SLOT) {
        m_itemName = item == nullptr ? L"" : item->getHoverName();
        setEditNameValue(m_itemName);
        setEditNameEditable(item != nullptr);
        if (item != nullptr) {
            updateItemName();
        }
    }
}

void IUIScene_AnvilMenu::setContainerData(AbstractContainerMenu* container,
                                          int id, int value) {}
